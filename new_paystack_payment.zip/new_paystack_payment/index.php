<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" 
    crossorigin="anonymous">
    <title>PayStack Payment Integration</title>
</head>
<body>

  <div class="container">
   <div class="row">
     <div class="col-md-8">
        <form id="paymentForm">
    <div style="padding-bottom:40px; padding-top:40px; color:white;">
        <button class="btn btn-dark">  Fill Out The Form To Make Payment &nbsp;</button>
    </div>
  <div class="form-group">
    <label for="email">Email &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;  &nbsp;</label>
    <input type="email" id="email-address" required />
  </div>
  <div class="form-group">
    <label for="first-name">Registered No</label>
    <input type="text" id="first-name" />
  </div>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()" style="padding-bottom:10px; margin-top:30px; padding-top:10px; background-color:black; color:white;"> Please Click Here To Make Payment &nbsp; &nbsp;</button>
  </div>
</form>
     </div>
   </div>
  </div>

<script src="https://js.paystack.co/v1/inline.js"></script> 

<br>
<script>

const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
  e.preventDefault();
  let handler = PaystackPop.setup({
    key: 'pk_test_5e30c3f1dcf5552b30bcc0ef9b8fc4af44f98b6a', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: 3000 * 100,
    firstname: "C",
    lastname: document.getElementById("first-name").value,
    ref: 'RoutePay'+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
       window.location = "http://localhost/new_paystack_payment/index.php?transaction=cancel";
       alert('Transaction cancelled');
    },
    callback: function(response){
       let message = 'Payment complete! Reference: ' + response.reference;
       alert(message);
       window.location = "http://localhost/new_paystack_payment/verify_transaction.php?reference=" + response.reference;
    }
  });
  handler.openIframe();
}

</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" 
integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" 
crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" 
integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" 
crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" 
integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>
</html>